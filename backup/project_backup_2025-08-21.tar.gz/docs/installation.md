# Установка и настройка PAGE X

## Быстрая установка

### 1. Скачивание проекта

```bash
# Клонирование репозитория
git clone https://github.com/your-username/PAGE-X.git
L10: cd PAGE-X

# Или скачивание ZIP архива
# Распакуйте архив в удобную папку
```

### 2. Установка зависимостей

```bash
# Установка Node.js зависимостей
npm install
```

### 3. Запуск локального сервера

```bash
# Node.js (рекомендуется)
npm run dev    # Для разработки с автоматической перезагрузкой
npm start      # Для продакшена

# Альтернативные варианты (если Node.js не установлен)
# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000

# PHP (если установлен)
php -S localhost:8000
```

### 4. Открытие в браузере

Перейдите по адресу: `http://localhost:8000`

### 5. Проверка состояния сервера

Для проверки работоспособности сервера перейдите по адресу: `http://localhost:8000/health`

## Настройка браузера

### Chrome / Edge

1. Откройте настройки браузера
2. Перейдите в раздел "При запуске"
3. Выберите "Открыть определенную страницу"
4. Добавьте URL вашей стартовой страницы

### Firefox

1. Откройте настройки браузера
2. Перейдите в раздел "Общие"
3. В поле "Домашняя страница" введите URL
4. Убедитесь, что выбрано "Показывать домашнюю страницу при запуске"

### Safari

1. Откройте настройки Safari
2. Перейдите в раздел "Общие"
3. В поле "Домашняя страница" введите URL

## Настройка новой вкладки

### Chrome / Edge

1. Установите расширение "New Tab Redirect"
2. В настройках расширения укажите URL стартовой страницы

### Firefox

1. Установите расширение "New Tab Override"
2. В настройках укажите URL стартовой страницы

## Размещение на хостинге

### GitHub Pages

1. Создайте репозиторий на GitHub
2. Загрузите файлы проекта
3. В настройках репозитория включите GitHub Pages
4. Выберите ветку и папку для публикации

### Netlify

1. Зарегистрируйтесь на Netlify
2. Подключите ваш GitHub репозиторий
3. Настройте параметры сборки (не требуются)
4. Получите URL для доступа

### Vercel

1. Зарегистрируйтесь на Vercel
2. Импортируйте ваш репозиторий
3. Настройте параметры проекта
4. Получите URL для доступа

## Настройка API ключей

### Погода (OpenWeatherMap)

1. Зарегистрируйтесь на [OpenWeatherMap](https://openweathermap.org/api)
2. Получите API ключ
3. В файле `src/components/status-bar.js` замените `demo` на ваш ключ:

```javascript
const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${CONFIG.temperature.location}&appid=YOUR_API_KEY&units=metric`);
```

### Криптовалюты (CoinGecko)

API CoinGecko бесплатный и не требует ключа, но имеет ограничения на количество запросов.

## Кастомизация

### Изменение ссылок

Отредактируйте файл `userconfig.js`:

```javascript
const CONFIG = new Config({
    tabs: [
        {
            name: 'my-tab',
            background_url: 'src/assets/bg-1.css',
            categories: [{
                name: 'my-category',
                links: [
                    {
                        url: 'https://example.com',
                        name: 'Example',
                        icon: 'ti ti-world',
                        icon_color: '#ff0000'
                    }
                ]
            }]
        }
    ]
});
```

### Изменение поисковых систем

```javascript
const CONFIG = new Config({
    searchProviders: [
        {
            name: 'My Search',
            url: 'https://mysearch.com/search?q=',
            icon: 'ti ti-search',
            shortcut: 'm'
        }
    ]
});
```

### Отключение компонентов

```javascript
const CONFIG = new Config({
    disabled: ['crypto-rate', 'weather-forecast']
});
```

## Устранение неполадок

### Проблемы с загрузкой

1. Убедитесь, что все файлы загружены
2. Проверьте консоль браузера на ошибки
3. Убедитесь, что сервер запущен

### Проблемы с API

1. Проверьте правильность API ключей
2. Убедитесь, что интернет-соединение активно
3. Проверьте лимиты API запросов

### Проблемы с отображением

1. Очистите кэш браузера
2. Проверьте поддержку CSS Grid и Flexbox
3. Убедитесь, что JavaScript включен

## Поддержка

Если у вас возникли проблемы:

1. Проверьте [Issues](https://github.com/your-username/PAGE-X/issues)
2. Создайте новый issue с описанием проблемы
3. Приложите скриншоты и логи консоли браузера 