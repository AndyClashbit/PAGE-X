# Анализ компонента Search Bar

## Общая информация

**Название компонента:** Search Bar  
**Тип компонента:** Web Component с Shadow DOM  
**Файл:** `src/components/search-bar.js`  
**Функциональность:** Поисковая строка с поддержкой нескольких поисковых провайдеров  
**Интеграция:** Основной элемент интерфейса PAGE X  

## Описание компонента

Search Bar представляет собой интерактивную поисковую строку, реализованную с использованием Web Components. Компонент позволяет пользователю выполнять поиск через различные поисковые системы (Google, Bing, DuckDuckGo и др.), переключаться между ними и настраивать их параметры. Компонент имеет стильный интерфейс в стиле Gruvbox и поддерживает горячие клавиши для быстрого доступа к функциям.

## Архитектура компонента

### Структура класса
```javascript
class SearchBar extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.providers = [
            { name: 'Google', url: 'https://www.google.com/search?q=', icon: 'google' },
            { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=', icon: 'duckduckgo' },
            { name: 'Bing', url: 'https://www.bing.com/search?q=', icon: 'bing' },
            // Другие провайдеры...
        ];
        this.activeProvider = 0;
        this.init();
    }
    
    // Методы инициализации
    init() { ... }
    render() { ... }
    loadStyles() { ... }
    
    // Методы поиска
    search(query) { ... }
    setActiveProvider(index) { ... }
    getActiveProvider() { ... }
    
    // Обработчики событий
    setupEventListeners() { ... }
    handleKeyDown(event) { ... }
    handleSubmit(event) { ... }
    handleProviderClick(event) { ... }
}
```

### HTML-структура (Shadow DOM)
```html
<div class="search-container">
    <div class="search-input-container">
        <input type="text" id="search-input" placeholder="Поиск..." />
        <button id="search-button" aria-label="Поиск">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                <circle cx="10" cy="10" r="7"></circle>
                <line x1="21" y1="21" x2="15" y2="15"></line>
            </svg>
        </button>
    </div>
    <div class="search-providers">
        <!-- Кнопки провайдеров поиска -->
        <button class="provider-button active" data-provider="0" aria-label="Google">
            <svg><!-- Google icon --></svg>
        </button>
        <button class="provider-button" data-provider="1" aria-label="DuckDuckGo">
            <svg><!-- DuckDuckGo icon --></svg>
        </button>
        <!-- Другие провайдеры... -->
    </div>
</div>
```

### CSS-структура
```css
:host {
    display: block;
    width: 100%;
    max-width: 600px;
    margin: 0 auto;
    font-family: 'Roboto', sans-serif;
}

.search-container {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.search-input-container {
    display: flex;
    position: relative;
    width: 100%;
}

#search-input {
    width: 100%;
    padding: 12px 50px 12px 16px;
    border: none;
    border-radius: 8px;
    background-color: var(--bg1, #3c3836);
    color: var(--fg, #ebdbb2);
    font-size: 16px;
    outline: none;
    transition: all 0.3s ease;
}

#search-input:focus {
    box-shadow: 0 0 0 2px var(--blue, #458588);
}

#search-button {
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: var(--fg, #ebdbb2);
    cursor: pointer;
    padding: 4px;
    border-radius: 4px;
    transition: all 0.2s ease;
}

#search-button:hover {
    background-color: var(--bg2, #504945);
}

.search-providers {
    display: flex;
    gap: 8px;
    justify-content: center;
}

.provider-button {
    background-color: var(--bg1, #3c3836);
    border: none;
    border-radius: 4px;
    padding: 6px;
    cursor: pointer;
    color: var(--fg, #ebdbb2);
    transition: all 0.2s ease;
}

.provider-button:hover {
    background-color: var(--bg2, #504945);
}

.provider-button.active {
    background-color: var(--blue, #458588);
    color: var(--bg0, #282828);
}

.provider-button svg {
    width: 20px;
    height: 20px;
}
```

## Функциональность

### Основные возможности
1. **Поиск через разные провайдеры** - поддержка нескольких поисковых систем
2. **Переключение провайдеров** - быстрое переключение между поисковыми системами
3. **Автофокус** - автоматический фокус на поле ввода при загрузке страницы
4. **Горячие клавиши** - поддержка клавиатурных сокращений
5. **Сохранение настроек** - запоминание последнего использованного провайдера
6. **Адаптивный дизайн** - корректное отображение на разных устройствах

### API компонента
```javascript
// Получение компонента
const searchBar = document.querySelector('search-bar');

// Выполнение поиска
searchBar.search('запрос');

// Установка активного провайдера
searchBar.setActiveProvider(1); // 0 - Google, 1 - DuckDuckGo, и т.д.

// Получение активного провайдера
const activeProvider = searchBar.getActiveProvider();

// Установка фокуса на поле ввода
searchBar.focus();

// Очистка поля ввода
searchBar.clear();
```

### События
```javascript
// Событие выполнения поиска
searchBar.addEventListener('search', (event) => {
    console.log('Search query:', event.detail.query);
    console.log('Provider:', event.detail.provider);
});

// Событие изменения провайдера
searchBar.addEventListener('provider-change', (event) => {
    console.log('New provider:', event.detail.provider);
});
```

### Горячие клавиши
- **Enter** - выполнение поиска
- **Tab** - переключение между полем ввода и кнопками провайдеров
- **Alt + 1-9** - быстрое переключение на соответствующий провайдер
- **Escape** - очистка поля ввода
- **Ctrl + K** - установка фокуса на поле ввода

## Особенности реализации

### Обработка поисковых запросов

Компонент обрабатывает поисковые запросы и перенаправляет их на соответствующий поисковый провайдер:

```javascript
search(query) {
    if (!query.trim()) return;
    
    const provider = this.providers[this.activeProvider];
    const searchUrl = provider.url + encodeURIComponent(query);
    
    // Отправка события поиска
    this.dispatchEvent(new CustomEvent('search', {
        detail: {
            query,
            provider: provider.name,
            url: searchUrl
        }
    }));
    
    // Открытие результатов поиска в новой вкладке
    window.open(searchUrl, '_blank');
}
```

### Переключение провайдеров

Компонент позволяет переключаться между различными поисковыми провайдерами:

```javascript
setActiveProvider(index) {
    if (index < 0 || index >= this.providers.length) return;
    
    this.activeProvider = index;
    
    // Обновление UI
    const buttons = this.shadowRoot.querySelectorAll('.provider-button');
    buttons.forEach((button, i) => {
        if (i === index) {
            button.classList.add('active');
        } else {
            button.classList.remove('active');
        }
    });
    
    // Сохранение выбора в localStorage
    localStorage.setItem('dawn_active_provider', index);
    
    // Отправка события изменения провайдера
    this.dispatchEvent(new CustomEvent('provider-change', {
        detail: {
            provider: this.providers[index]
        }
    }));
}
```

### Обработка клавиатурных событий

Компонент обрабатывает клавиатурные события для удобного использования:

```javascript
handleKeyDown(event) {
    const input = this.shadowRoot.getElementById('search-input');
    
    // Горячие клавиши для переключения провайдеров (Alt + цифра)
    if (event.altKey && event.key >= '1' && event.key <= '9') {
        const index = parseInt(event.key) - 1;
        if (index < this.providers.length) {
            this.setActiveProvider(index);
            event.preventDefault();
        }
        return;
    }
    
    // Escape - очистка поля ввода
    if (event.key === 'Escape') {
        input.value = '';
        event.preventDefault();
        return;
    }
    
    // Enter - выполнение поиска
    if (event.key === 'Enter' && document.activeElement === input) {
        this.search(input.value);
        event.preventDefault();
    }
}
```

## Интеграция в PAGE X

### Подключение компонента
```html
<!-- В index.html -->
<div class="search-section">
    <search-bar id="main-search"></search-bar>
</div>
```

### Конфигурация
```javascript
// В userconfig.js
searchBar: {
    providers: [
        { name: 'Google', url: 'https://www.google.com/search?q=', icon: 'google' },
        { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=', icon: 'duckduckgo' },
        { name: 'Bing', url: 'https://www.bing.com/search?q=', icon: 'bing' },
        { name: 'Yandex', url: 'https://yandex.ru/search/?text=', icon: 'yandex' },
        { name: 'Brave', url: 'https://search.brave.com/search?q=', icon: 'brave' }
    ],
    defaultProvider: 0,
    openInNewTab: true,
    autoFocus: true,
    placeholder: 'Поиск...',
    hotkeys: {
        focus: 'ctrl+k',
        clear: 'escape'
    }
}
```

### Инициализация в app.js
```javascript
class DawnApp {
    constructor() {
        this.searchBar = null;
        this.init();
    }

    init() {
        this.setupComponents();
        this.setupEventListeners();
        this.applySettings();
    }

    setupComponents() {
        this.searchBar = document.querySelector('search-bar');
        
        if (this.searchBar) {
            this.initSearchBar();
        }
    }
    
    initSearchBar() {
        const config = CONFIG.searchBar;
        
        // Установка провайдеров из конфигурации
        if (config.providers && Array.isArray(config.providers)) {
            this.searchBar.providers = config.providers;
        }
        
        // Установка активного провайдера
        if (typeof config.defaultProvider === 'number') {
            this.searchBar.setActiveProvider(config.defaultProvider);
        }
        
        // Установка плейсхолдера
        if (config.placeholder) {
            this.searchBar.setPlaceholder(config.placeholder);
        }
        
        // Автофокус
        if (config.autoFocus) {
            setTimeout(() => this.searchBar.focus(), 100);
        }
    }
    
    setupEventListeners() {
        // Обработка события поиска
        this.searchBar.addEventListener('search', (event) => {
            console.log(`Searching for "${event.detail.query}" using ${event.detail.provider}`);
            
            // Аналитика или другие действия...
        });
    }
}
```

## Тестирование

### Тестовая страница
```html
<!-- test-search-bar.html -->
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тест Search Bar</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #282828;
            color: #ebdbb2;
        }
        
        .test-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .test-section {
            padding: 20px;
            border: 1px solid #504945;
            border-radius: 8px;
        }
        
        .test-title {
            margin-top: 0;
            color: #b8bb26;
        }
        
        .test-description {
            margin-bottom: 20px;
        }
        
        .test-button {
            background-color: #504945;
            color: #ebdbb2;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 8px;
            margin-bottom: 8px;
        }
        
        .test-button:hover {
            background-color: #665c54;
        }
        
        .test-log {
            background-color: #3c3836;
            padding: 10px;
            border-radius: 4px;
            font-family: monospace;
            max-height: 200px;
            overflow-y: auto;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Тест Search Bar</h1>
    
    <div class="test-container">
        <div class="test-section">
            <h2 class="test-title">Базовое использование</h2>
            <p class="test-description">Стандартная поисковая строка с несколькими провайдерами.</p>
            
            <search-bar id="basic-search"></search-bar>
        </div>
        
        <div class="test-section">
            <h2 class="test-title">Пользовательская конфигурация</h2>
            <p class="test-description">Поисковая строка с пользовательскими настройками.</p>
            
            <search-bar id="custom-search"></search-bar>
            
            <div style="margin-top: 20px;">
                <button class="test-button" onclick="setCustomProviders()">Установить провайдеры</button>
                <button class="test-button" onclick="setActiveProvider(0)">Google</button>
                <button class="test-button" onclick="setActiveProvider(1)">Yandex</button>
                <button class="test-button" onclick="setActiveProvider(2)">GitHub</button>
            </div>
        </div>
        
        <div class="test-section">
            <h2 class="test-title">События</h2>
            <p class="test-description">Отслеживание событий поисковой строки.</p>
            
            <search-bar id="event-search"></search-bar>
            
            <div class="test-log" id="event-log"></div>
        </div>
    </div>
    
    <!-- Components -->
    <script src="src/components/search-bar.js"></script>
    
    <!-- Test Scripts -->
    <script>
        // Базовая поисковая строка
        const basicSearch = document.getElementById('basic-search');
        
        // Пользовательская поисковая строка
        const customSearch = document.getElementById('custom-search');
        
        function setCustomProviders() {
            customSearch.providers = [
                { name: 'Google', url: 'https://www.google.com/search?q=', icon: 'google' },
                { name: 'Yandex', url: 'https://yandex.ru/search/?text=', icon: 'yandex' },
                { name: 'GitHub', url: 'https://github.com/search?q=', icon: 'github' }
            ];
            customSearch.render();
        }
        
        function setActiveProvider(index) {
            customSearch.setActiveProvider(index);
        }
        
        // События
        const eventSearch = document.getElementById('event-search');
        const eventLog = document.getElementById('event-log');
        
        function logEvent(message) {
            const logItem = document.createElement('div');
            logItem.textContent = `${new Date().toLocaleTimeString()}: ${message}`;
            eventLog.appendChild(logItem);
            eventLog.scrollTop = eventLog.scrollHeight;
        }
        
        eventSearch.addEventListener('search', (event) => {
            logEvent(`Search: "${event.detail.query}" using ${event.detail.provider}`);
        });
        
        eventSearch.addEventListener('provider-change', (event) => {
            logEvent(`Provider changed to: ${event.detail.provider.name}`);
        });
        
        // Инициализация
        window.addEventListener('DOMContentLoaded', () => {
            setCustomProviders();
        });
    </script>
</body>
</html>
```

## Совместимость

### Браузеры
- ✅ Chrome 60+
- ✅ Firefox 55+
- ✅ Safari 10.1+
- ✅ Edge 79+

### Устройства
- ✅ Десктопы
- ✅ Ноутбуки
- ✅ Планшеты
- ✅ Мобильные устройства

### Доступность
- ✅ Поддержка клавиатурной навигации
- ✅ ARIA-атрибуты для скринридеров
- ✅ Высокий контраст для лучшей читаемости
- ✅ Фокусные состояния для элементов управления

## Рекомендации по улучшению

### Технические улучшения
1. **Автодополнение** - добавление функции автодополнения запросов
2. **История поиска** - сохранение и отображение истории поисковых запросов
3. **Поисковые подсказки** - интеграция с API поисковых систем для получения подсказок
4. **Настраиваемые горячие клавиши** - возможность настройки клавиатурных сокращений
5. **Локализация** - поддержка разных языков интерфейса

### Функциональные улучшения
1. **Специальные команды** - поддержка специальных команд (например, !w для поиска в Wikipedia)
2. **Настраиваемые провайдеры** - возможность добавления и редактирования провайдеров
3. **Категории поиска** - группировка провайдеров по категориям (общий поиск, изображения, видео и т.д.)
4. **Интеграция с закладками** - поиск по закладкам браузера
5. **Голосовой поиск** - поддержка голосового ввода

## Заключение

Компонент Search Bar представляет собой мощный и гибкий инструмент для выполнения поисковых запросов через различные поисковые системы. Компонент имеет стильный интерфейс в стиле Gruvbox, поддерживает горячие клавиши и предоставляет удобный API для интеграции в проект PAGE X.

Использование Web Components и Shadow DOM обеспечивает инкапсуляцию стилей и функциональности, что делает компонент независимым и переиспользуемым. Компонент также обеспечивает хорошую доступность и совместимость с различными устройствами и браузерами.

Дальнейшее развитие компонента может включать добавление функций автодополнения, истории поиска, поисковых подсказок и других улучшений, которые сделают его еще более удобным и функциональным.