# Тестирование IconLoader

## 🚀 Быстрый старт

1. **Сервер уже запущен** на `http://localhost:8000`
2. **Откройте браузер** и перейдите по адресу
3. **Проверьте иконки** на главной странице

## 🧪 Тестовые страницы

### Основная страница
**URL:** `http://localhost:8000`

Проверьте, что иконки отображаются в карточках сайтов:
- GitHub, Twitter, Reddit, Discord, Telegram
- Stack Overflow, Dev.to, Medium, CodePen
- YouTube, Netflix, Spotify, Twitch, Steam

### Простой тест
**URL:** `http://localhost:8000/test-simple-icons.html`

Изолированный тест IconLoader с подробной информацией о каждом сайте.

### Полный тест
**URL:** `http://localhost:8000/test-icons.html`

Расширенный тест с множеством сайтов и функциями управления.

## ✅ Что должно работать

### Fallback иконки
- [ ] **GitHub** - `ti ti-brand-github`
- [ ] **Twitter** - `ti ti-brand-twitter`
- [ ] **Reddit** - `ti ti-brand-reddit`
- [ ] **Discord** - `ti ti-brand-discord`
- [ ] **Telegram** - `ti ti-brand-telegram`
- [ ] **YouTube** - `ti ti-brand-youtube`
- [ ] **Stack Overflow** - `ti ti-brand-stackoverflow`
- [ ] **Dev.to** - `ti ti-brand-dev`
- [ ] **Medium** - `ti ti-brand-medium`
- [ ] **CodePen** - `ti ti-brand-codepen`
- [ ] **JSFiddle** - `ti ti-brand-jsfiddle`
- [ ] **Replit** - `ti ti-brand-replit`
- [ ] **Netflix** - `ti ti-brand-netflix`
- [ ] **Spotify** - `ti ti-brand-spotify`
- [ ] **Twitch** - `ti ti-brand-twitch`
- [ ] **Steam** - `ti ti-brand-steam`

### Favicon загрузка
- [ ] **Прямые favicon** с сайтов
- [ ] **Google Favicon Service** как резерв
- [ ] **Favicon.io** как дополнительный источник

### Default иконки
- [ ] **🌐 иконка** для неизвестных сайтов
- [ ] **Обработка ошибок** при загрузке

## 🔍 Диагностика

### Проверка консоли
1. Откройте **Developer Tools** (F12)
2. Перейдите на вкладку **Console**
3. Ищите сообщения от IconLoader:
   ```
   IconLoader компонент загружен: ƒ IconLoader()
   Найдено иконок: 5
   Иконка 1: https://github.com
   ```

### Проверка элементов
1. В **Developer Tools** перейдите на вкладку **Elements**
2. Найдите элементы `<icon-loader>`
3. Проверьте их Shadow DOM
4. Убедитесь, что иконки отображаются внутри

### Проверка стилей
1. Убедитесь, что Tabler Icons загружены:
   ```html
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons@latest/iconfont/tabler-icons.min.css">
   ```

2. Проверьте CSS классы в Shadow DOM:
   ```css
   .ti {
       font-family: 'tabler-icons' !important;
   }
   ```

## 🚨 Устранение неполадок

### Иконки не отображаются
1. **Проверьте загрузку компонента**:
   ```javascript
   console.log('IconLoader:', customElements.get('icon-loader'));
   ```

2. **Проверьте Tabler Icons**:
   ```javascript
   console.log('Tabler Icons loaded:', document.querySelector('link[href*="tabler-icons"]'));
   ```

3. **Проверьте атрибуты**:
   ```javascript
   const loader = document.querySelector('icon-loader');
   console.log('URL:', loader.url);
   console.log('Size:', loader.size);
   ```

### Fallback иконки не работают
1. **Проверьте CSS классы**:
   ```javascript
   const icon = loader.shadowRoot.querySelector('.ti');
   console.log('Icon class:', icon?.className);
   ```

2. **Проверьте домен**:
   ```javascript
   console.log('Domain:', loader.extractDomain(loader.url));
   ```

3. **Проверьте fallback список**:
   ```javascript
   console.log('Fallback icons:', loader.fallbackIcons);
   ```

### Медленная загрузка
1. **Проверьте кэш**:
   ```javascript
   console.log('Cache size:', loader.cache.size);
   ```

2. **Проверьте сетевые запросы**:
   - Откройте вкладку **Network** в Developer Tools
   - Ищите запросы к favicon

## 🎯 Ожидаемый результат

После успешной интеграции вы должны увидеть:

1. **Правильные иконки** для всех известных сайтов
2. **Fallback иконки** для популярных сайтов
3. **Default иконку 🌐** для неизвестных сайтов
4. **Плавную загрузку** без ошибок
5. **Кэширование** для быстрой работы

## 🌟 Дополнительные возможности

### Добавление новых сайтов
```javascript
// В icon-loader.js
fallbackIcons = {
    // ... существующие иконки
    'new-site.com': 'ti ti-brand-new-site'
}
```

### Кастомизация размеров
```html
<icon-loader url="https://github.com" size="48px"></icon-loader>
```

### Изменение цветов
```html
<icon-loader url="https://github.com" color="#ff0000"></icon-loader>
```

---

**Сервер запущен на:** `http://localhost:8000`

**Тестовые страницы:**
- **Основная:** `http://localhost:8000`
- **Простой тест:** `http://localhost:8000/test-simple-icons.html`
- **Полный тест:** `http://localhost:8000/test-icons.html`

**Готово к тестированию!** 🎨✨ 