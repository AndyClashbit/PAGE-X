# Анализ компонента Tabs Container

## Общая информация

**Название компонента:** Tabs Container  
**Тип компонента:** Web Component с Shadow DOM  
**Файл:** `src/components/tabs-container.js`  
**Функциональность:** Управление вкладками с содержимым  
**Интеграция:** Основной элемент интерфейса PAGE X  

## Описание компонента

Tabs Container представляет собой компонент для управления вкладками, реализованный с использованием Web Components. Компонент позволяет создавать, отображать и переключаться между различными вкладками, каждая из которых может содержать произвольный контент. Компонент имеет стильный интерфейс в стиле Gruvbox, поддерживает горячие клавиши для быстрого доступа к вкладкам и сохраняет состояние между сессиями.

## Архитектура компонента

### Структура класса
```javascript
class TabsContainer extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.tabs = [];
        this.activeTab = 0;
        this.init();
    }
    
    // Методы инициализации
    init() { ... }
    render() { ... }
    loadStyles() { ... }
    
    // Методы управления вкладками
    addTab(tab) { ... }
    removeTab(id) { ... }
    setActiveTab(index) { ... }
    getActiveTab() { ... }
    renderTabs() { ... }
    renderTabContent() { ... }
    
    // Обработчики событий
    setupEventListeners() { ... }
    handleTabClick(event) { ... }
    handleKeyDown(event) { ... }
}
```

### HTML-структура (Shadow DOM)
```html
<div class="tabs-container">
    <div class="tabs-header">
        <div class="tabs-list">
            <!-- Вкладки -->
            <div class="tab active" data-id="tab1">
                <icon-loader url="https://example.com"></icon-loader>
                <span class="tab-title">Вкладка 1</span>
            </div>
            <div class="tab" data-id="tab2">
                <icon-loader url="https://example.com"></icon-loader>
                <span class="tab-title">Вкладка 2</span>
            </div>
            <!-- Другие вкладки... -->
        </div>
        <div class="tabs-actions">
            <button id="add-tab-button" aria-label="Добавить вкладку">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
            </button>
        </div>
    </div>
    <div class="tabs-content">
        <!-- Содержимое активной вкладки -->
        <div class="tab-content active" data-id="tab1">
            <!-- Содержимое вкладки 1 -->
        </div>
        <div class="tab-content" data-id="tab2">
            <!-- Содержимое вкладки 2 -->
        </div>
        <!-- Другие содержимые вкладок... -->
    </div>
</div>
```

### CSS-структура
```css
:host {
    display: block;
    width: 100%;
    height: 100%;
    font-family: 'Roboto', sans-serif;
}

.tabs-container {
    display: flex;
    flex-direction: column;
    height: 100%;
    background-color: var(--bg0, #282828);
    color: var(--fg, #ebdbb2);
    border-radius: 8px;
    overflow: hidden;
}

.tabs-header {
    display: flex;
    align-items: center;
    padding: 8px;
    background-color: var(--bg1, #3c3836);
    border-bottom: 1px solid var(--bg2, #504945);
}

.tabs-list {
    display: flex;
    flex-grow: 1;
    overflow-x: auto;
    scrollbar-width: thin;
    scrollbar-color: var(--bg3, #665c54) var(--bg1, #3c3836);
}

.tabs-list::-webkit-scrollbar {
    height: 6px;
}

.tabs-list::-webkit-scrollbar-track {
    background: var(--bg1, #3c3836);
}

.tabs-list::-webkit-scrollbar-thumb {
    background-color: var(--bg3, #665c54);
    border-radius: 3px;
}

.tab {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background-color: var(--bg1, #3c3836);
    border-radius: 4px;
    margin-right: 4px;
    cursor: pointer;
    white-space: nowrap;
    transition: all 0.2s ease;
}

.tab:hover {
    background-color: var(--bg2, #504945);
}

.tab.active {
    background-color: var(--blue, #458588);
    color: var(--bg0, #282828);
}

.tab-title {
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
}

.tabs-actions {
    display: flex;
    align-items: center;
}

#add-tab-button {
    background: none;
    border: none;
    color: var(--fg, #ebdbb2);
    cursor: pointer;
    padding: 4px;
    border-radius: 4px;
    transition: all 0.2s ease;
}

#add-tab-button:hover {
    background-color: var(--bg2, #504945);
}

.tabs-content {
    flex-grow: 1;
    overflow: auto;
    position: relative;
}

.tab-content {
    display: none;
    height: 100%;
    padding: 16px;
    overflow: auto;
}

.tab-content.active {
    display: block;
}
```

## Функциональность

### Основные возможности
1. **Управление вкладками** - создание, удаление и переключение между вкладками
2. **Сохранение состояния** - запоминание активной вкладки между сессиями
3. **Горячие клавиши** - поддержка клавиатурных сокращений для управления вкладками
4. **Иконки вкладок** - отображение иконок сайтов для вкладок
5. **Адаптивный дизайн** - корректное отображение на разных устройствах
6. **Прокрутка вкладок** - горизонтальная прокрутка при большом количестве вкладок

### API компонента
```javascript
// Получение компонента
const tabsContainer = document.querySelector('tabs-container');

// Добавление новой вкладки
tabsContainer.addTab({
    id: 'tab3',
    title: 'Новая вкладка',
    url: 'https://example.com',
    content: '<div>Содержимое новой вкладки</div>'
});

// Удаление вкладки
tabsContainer.removeTab('tab3');

// Установка активной вкладки
tabsContainer.setActiveTab(1); // 0 - первая вкладка, 1 - вторая вкладка, и т.д.

// Получение активной вкладки
const activeTab = tabsContainer.getActiveTab();

// Обновление содержимого вкладки
tabsContainer.updateTabContent('tab1', '<div>Новое содержимое</div>');
```

### События
```javascript
// Событие изменения активной вкладки
tabsContainer.addEventListener('tab-change', (event) => {
    console.log('Active tab changed:', event.detail.tab);
});

// Событие добавления вкладки
tabsContainer.addEventListener('tab-add', (event) => {
    console.log('Tab added:', event.detail.tab);
});

// Событие удаления вкладки
tabsContainer.addEventListener('tab-remove', (event) => {
    console.log('Tab removed:', event.detail.tabId);
});
```

### Горячие клавиши
- **Ctrl + Tab** - переключение на следующую вкладку
- **Ctrl + Shift + Tab** - переключение на предыдущую вкладку
- **Ctrl + 1-9** - быстрое переключение на соответствующую вкладку
- **Ctrl + T** - создание новой вкладки
- **Ctrl + W** - закрытие текущей вкладки

## Особенности реализации

### Управление вкладками

Компонент управляет вкладками через массив объектов, каждый из которых представляет отдельную вкладку:

```javascript
addTab(tab) {
    // Проверка обязательных полей
    if (!tab.id || !tab.title) {
        console.error('Tab must have id and title');
        return;
    }
    
    // Добавление вкладки в массив
    this.tabs.push(tab);
    
    // Обновление UI
    this.renderTabs();
    
    // Установка новой вкладки как активной
    this.setActiveTab(this.tabs.length - 1);
    
    // Сохранение состояния
    this.saveTabs();
    
    // Отправка события добавления вкладки
    this.dispatchEvent(new CustomEvent('tab-add', {
        detail: { tab }
    }));
}

removeTab(id) {
    // Поиск индекса вкладки
    const index = this.tabs.findIndex(tab => tab.id === id);
    if (index === -1) return;
    
    // Удаление вкладки из массива
    this.tabs.splice(index, 1);
    
    // Обновление активной вкладки
    if (this.tabs.length === 0) {
        // Если вкладок не осталось, создаем пустую вкладку
        this.addTab({
            id: 'empty-tab',
            title: 'Пустая вкладка',
            content: '<div class="empty-tab">Нет содержимого</div>'
        });
    } else if (this.activeTab >= this.tabs.length) {
        // Если активная вкладка была удалена, устанавливаем последнюю вкладку как активную
        this.setActiveTab(this.tabs.length - 1);
    } else {
        // Обновляем UI
        this.renderTabs();
        this.renderTabContent();
    }
    
    // Сохранение состояния
    this.saveTabs();
    
    // Отправка события удаления вкладки
    this.dispatchEvent(new CustomEvent('tab-remove', {
        detail: { tabId: id }
    }));
}
```

### Переключение вкладок

Компонент обеспечивает переключение между вкладками и отображение соответствующего содержимого:

```javascript
setActiveTab(index) {
    if (index < 0 || index >= this.tabs.length) return;
    
    this.activeTab = index;
    
    // Обновление UI
    const tabElements = this.shadowRoot.querySelectorAll('.tab');
    tabElements.forEach((tab, i) => {
        if (i === index) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
    
    // Обновление содержимого
    this.renderTabContent();
    
    // Сохранение активной вкладки
    localStorage.setItem('dawn_active_tab', index);
    
    // Отправка события изменения вкладки
    this.dispatchEvent(new CustomEvent('tab-change', {
        detail: { tab: this.tabs[index] }
    }));
}

renderTabContent() {
    const tabsContent = this.shadowRoot.querySelector('.tabs-content');
    const activeTab = this.tabs[this.activeTab];
    
    // Очистка содержимого
    tabsContent.innerHTML = '';
    
    if (activeTab) {
        // Создание элемента содержимого
        const contentElement = document.createElement('div');
        contentElement.className = 'tab-content active';
        contentElement.dataset.id = activeTab.id;
        
        // Установка содержимого
        if (activeTab.content) {
            contentElement.innerHTML = activeTab.content;
        } else if (activeTab.url) {
            // Если указан URL, создаем iframe
            const iframe = document.createElement('iframe');
            iframe.src = activeTab.url;
            iframe.width = '100%';
            iframe.height = '100%';
            iframe.frameBorder = '0';
            contentElement.appendChild(iframe);
        }
        
        // Добавление содержимого в контейнер
        tabsContent.appendChild(contentElement);
    }
}
```

### Сохранение состояния

Компонент сохраняет состояние вкладок и активную вкладку в localStorage:

```javascript
saveTabs() {
    // Сохранение только необходимых данных
    const tabsData = this.tabs.map(tab => ({
        id: tab.id,
        title: tab.title,
        url: tab.url
    }));
    
    localStorage.setItem('dawn_tabs', JSON.stringify(tabsData));
}

loadTabs() {
    const tabsData = localStorage.getItem('dawn_tabs');
    if (tabsData) {
        try {
            const tabs = JSON.parse(tabsData);
            this.tabs = tabs;
            
            // Загрузка активной вкладки
            const activeTab = localStorage.getItem('dawn_active_tab');
            if (activeTab !== null) {
                this.activeTab = parseInt(activeTab);
            }
            
            // Обновление UI
            this.renderTabs();
            this.renderTabContent();
        } catch (error) {
            console.error('Error loading tabs:', error);
        }
    }
}
```

## Интеграция в PAGE X

### Подключение компонента
```html
<!-- В index.html -->
<div class="tabs-section">
    <tabs-container id="main-tabs"></tabs-container>
</div>
```

### Конфигурация
```javascript
// В userconfig.js
tabsContainer: {
    defaultTabs: [
        {
            id: 'bookmarks',
            title: 'Закладки',
            content: '<div class="bookmarks-container">...</div>'
        },
        {
            id: 'news',
            title: 'Новости',
            url: 'https://news.example.com'
        },
        {
            id: 'weather',
            title: 'Погода',
            content: '<weather-widget location="Moscow"></weather-widget>'
        }
    ],
    rememberTabs: true,
    maxTabs: 10,
    showIcons: true,
    showAddButton: true,
    showCloseButton: true
}
```

### Инициализация в app.js
```javascript
class DawnApp {
    constructor() {
        this.tabsContainer = null;
        this.init();
    }

    init() {
        this.setupComponents();
        this.setupEventListeners();
        this.applySettings();
    }

    setupComponents() {
        this.tabsContainer = document.querySelector('tabs-container');
        
        if (this.tabsContainer) {
            this.initTabsContainer();
        }
    }
    
    initTabsContainer() {
        const config = CONFIG.tabsContainer;
        
        // Если не загружены сохраненные вкладки, используем вкладки из конфигурации
        if (this.tabsContainer.tabs.length === 0 && config.defaultTabs) {
            config.defaultTabs.forEach(tab => {
                this.tabsContainer.addTab(tab);
            });
        }
        
        // Настройка максимального количества вкладок
        if (config.maxTabs) {
            this.tabsContainer.maxTabs = config.maxTabs;
        }
        
        // Настройка отображения иконок
        if (typeof config.showIcons === 'boolean') {
            this.tabsContainer.showIcons = config.showIcons;
        }
        
        // Настройка отображения кнопки добавления
        if (typeof config.showAddButton === 'boolean') {
            this.tabsContainer.showAddButton = config.showAddButton;
        }
        
        // Настройка отображения кнопки закрытия
        if (typeof config.showCloseButton === 'boolean') {
            this.tabsContainer.showCloseButton = config.showCloseButton;
        }
    }
    
    setupEventListeners() {
        // Обработка события изменения вкладки
        this.tabsContainer.addEventListener('tab-change', (event) => {
            console.log(`Tab changed to: ${event.detail.tab.title}`);
            
            // Аналитика или другие действия...
        });
    }
}
```

## Тестирование

### Тестовая страница
```html
<!-- test-tabs-container.html -->
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тест Tabs Container</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #282828;
            color: #ebdbb2;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .header {
            padding: 20px;
            background-color: #3c3836;
        }
        
        .test-title {
            margin: 0;
            color: #b8bb26;
        }
        
        .test-description {
            margin-top: 10px;
            margin-bottom: 0;
        }
        
        .test-controls {
            padding: 10px 20px;
            background-color: #504945;
            display: flex;
            gap: 10px;
        }
        
        .test-button {
            background-color: #665c54;
            color: #ebdbb2;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .test-button:hover {
            background-color: #7c6f64;
        }
        
        .test-container {
            flex-grow: 1;
            padding: 20px;
            display: flex;
            flex-direction: column;
        }
        
        #tabs-test {
            flex-grow: 1;
            border: 1px solid #504945;
            border-radius: 8px;
            overflow: hidden;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1 class="test-title">Тест Tabs Container</h1>
        <p class="test-description">Тестирование компонента управления вкладками.</p>
    </div>
    
    <div class="test-controls">
        <button class="test-button" onclick="addTab()">Добавить вкладку</button>
        <button class="test-button" onclick="removeCurrentTab()">Удалить текущую вкладку</button>
        <button class="test-button" onclick="nextTab()">Следующая вкладка</button>
        <button class="test-button" onclick="prevTab()">Предыдущая вкладка</button>
        <button class="test-button" onclick="resetTabs()">Сбросить вкладки</button>
    </div>
    
    <div class="test-container">
        <tabs-container id="tabs-test"></tabs-container>
    </div>
    
    <!-- Components -->
    <script src="src/components/icon-loader.js"></script>
    <script src="src/components/tabs-container.js"></script>
    
    <!-- Test Scripts -->
    <script>
        const tabsContainer = document.getElementById('tabs-test');
        let tabCounter = 1;
        
        // Добавление вкладки
        function addTab() {
            const id = `tab-${Date.now()}`;
            const title = `Вкладка ${tabCounter++}`;
            
            tabsContainer.addTab({
                id,
                title,
                url: 'https://example.com',
                content: `<div style="padding: 20px;"><h2>${title}</h2><p>Содержимое вкладки ${tabCounter - 1}</p></div>`
            });
        }
        
        // Удаление текущей вкладки
        function removeCurrentTab() {
            const activeTab = tabsContainer.getActiveTab();
            if (activeTab) {
                tabsContainer.removeTab(activeTab.id);
            }
        }
        
        // Переключение на следующую вкладку
        function nextTab() {
            const currentIndex = tabsContainer.activeTab;
            const nextIndex = (currentIndex + 1) % tabsContainer.tabs.length;
            tabsContainer.setActiveTab(nextIndex);
        }
        
        // Переключение на предыдущую вкладку
        function prevTab() {
            const currentIndex = tabsContainer.activeTab;
            const prevIndex = (currentIndex - 1 + tabsContainer.tabs.length) % tabsContainer.tabs.length;
            tabsContainer.setActiveTab(prevIndex);
        }
        
        // Сброс вкладок
        function resetTabs() {
            // Удаление всех вкладок
            while (tabsContainer.tabs.length > 0) {
                tabsContainer.removeTab(tabsContainer.tabs[0].id);
            }
            
            // Добавление начальных вкладок
            tabsContainer.addTab({
                id: 'tab-1',
                title: 'Закладки',
                content: '<div style="padding: 20px;"><h2>Закладки</h2><p>Ваши закладки будут здесь</p></div>'
            });
            
            tabsContainer.addTab({
                id: 'tab-2',
                title: 'Новости',
                content: '<div style="padding: 20px;"><h2>Новости</h2><p>Последние новости</p></div>'
            });
            
            tabCounter = 3;
        }
        
        // Инициализация
        window.addEventListener('DOMContentLoaded', () => {
            // Если нет сохраненных вкладок, добавляем начальные вкладки
            if (tabsContainer.tabs.length === 0) {
                resetTabs();
            }
            
            // Обработка событий
            tabsContainer.addEventListener('tab-change', (event) => {
                console.log('Tab changed:', event.detail.tab);
            });
            
            tabsContainer.addEventListener('tab-add', (event) => {
                console.log('Tab added:', event.detail.tab);
            });
            
            tabsContainer.addEventListener('tab-remove', (event) => {
                console.log('Tab removed:', event.detail.tabId);
            });
        });
    </script>
</body>
</html>
```

## Совместимость

### Браузеры
- ✅ Chrome 60+
- ✅ Firefox 55+
- ✅ Safari 10.1+
- ✅ Edge 79+

### Устройства
- ✅ Десктопы
- ✅ Ноутбуки
- ✅ Планшеты
- ⚠️ Мобильные устройства (требуется адаптация интерфейса)

### Доступность
- ✅ Поддержка клавиатурной навигации
- ✅ ARIA-атрибуты для скринридеров
- ✅ Высокий контраст для лучшей читаемости
- ✅ Фокусные состояния для элементов управления

## Рекомендации по улучшению

### Технические улучшения
1. **Drag and Drop** - возможность перетаскивания вкладок для изменения их порядка
2. **Контекстное меню** - добавление контекстного меню для вкладок
3. **Вложенные вкладки** - поддержка вложенных вкладок или групп вкладок
4. **Разделение области** - возможность разделения области содержимого для отображения нескольких вкладок одновременно
5. **Оптимизация производительности** - улучшение производительности при большом количестве вкладок

### Функциональные улучшения
1. **Закрепление вкладок** - возможность закрепления важных вкладок
2. **Поиск по вкладкам** - функция поиска по заголовкам и содержимому вкладок
3. **Экспорт/импорт** - возможность экспорта и импорта конфигурации вкладок
4. **Уведомления** - поддержка уведомлений для вкладок
5. **Темы** - поддержка различных тем оформления

## Заключение

Компонент Tabs Container представляет собой мощный и гибкий инструмент для управления вкладками в проекте PAGE X. Компонент имеет стильный интерфейс в стиле Gruvbox, поддерживает горячие клавиши и предоставляет удобный API для интеграции и настройки.

Использование Web Components и Shadow DOM обеспечивает инкапсуляцию стилей и функциональности, что делает компонент независимым и переиспользуемым. Компонент также обеспечивает хорошую доступность и совместимость с различными устройствами и браузерами.

Дальнейшее развитие компонента может включать добавление функций перетаскивания вкладок, контекстного меню, вложенных вкладок и других улучшений, которые сделают его еще более удобным и функциональным.