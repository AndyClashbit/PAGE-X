# Анализ компонента Icon Loader

## Общая информация

**Название компонента:** Icon Loader  
**Тип компонента:** Web Component с Shadow DOM  
**Файл:** `src/components/icon-loader.js`  
**Функциональность:** Автоматическая загрузка и отображение иконок сайтов  
**Интеграция:** Используется в компоненте Tabs Container для отображения иконок вкладок  

## Описание компонента

Icon Loader представляет собой специализированный веб-компонент, предназначенный для автоматической загрузки и отображения иконок сайтов (favicon). Компонент использует несколько источников для получения иконок, включая прямое обращение к favicon сайта, Google Favicon Service и резервные иконки из библиотеки Tabler Icons. Компонент также реализует кэширование иконок для повышения производительности и уменьшения количества запросов к серверам.

## Архитектура компонента

### Структура класса
```javascript
class IconLoader extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.iconCache = {};
        this.init();
    }
    
    // Методы инициализации
    init() { ... }
    render() { ... }
    loadStyles() { ... }
    
    // Методы загрузки иконок
    loadIcon(url) { ... }
    fetchFavicon(url) { ... }
    fetchGoogleFavicon(url) { ... }
    loadFallbackIcon() { ... }
    
    // Методы кэширования
    cacheIcon(url, iconData) { ... }
    getCachedIcon(url) { ... }
    clearCache() { ... }
    
    // Обработчики событий
    handleError() { ... }
    handleLoad() { ... }
}
```

### HTML-структура (Shadow DOM)
```html
<div class="icon-container">
    <img id="icon" src="" alt="Site Icon" />
    <div id="fallback-icon" class="hidden">
        <!-- SVG иконка по умолчанию -->
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
            <path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"></path>
            <path d="M3.6 9h16.8"></path>
            <path d="M3.6 15h16.8"></path>
            <path d="M11.5 3a17 17 0 0 0 0 18"></path>
            <path d="M12.5 3a17 17 0 0 1 0 18"></path>
        </svg>
    </div>
    <div id="loader" class="hidden">
        <!-- Индикатор загрузки -->
        <div class="spinner"></div>
    </div>
</div>
```

### CSS-структура
```css
:host {
    display: inline-block;
    width: 16px;
    height: 16px;
    vertical-align: middle;
}

.icon-container {
    position: relative;
    width: 100%;
    height: 100%;
}

#icon {
    width: 100%;
    height: 100%;
    object-fit: contain;
}

#fallback-icon {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-color, #ebdbb2);
}

#loader {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.spinner {
    width: 12px;
    height: 12px;
    border: 2px solid rgba(235, 219, 178, 0.3);
    border-radius: 50%;
    border-top-color: var(--text-color, #ebdbb2);
    animation: spin 1s linear infinite;
}

.hidden {
    display: none;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
```

## Функциональность

### Основные возможности
1. **Автоматическая загрузка иконок** - загрузка favicon сайтов по URL
2. **Множественные источники** - использование нескольких источников для получения иконок
3. **Кэширование** - сохранение загруженных иконок в кэше для повторного использования
4. **Резервные иконки** - отображение стандартной иконки при ошибке загрузки
5. **Индикатор загрузки** - отображение анимации загрузки
6. **Обработка ошибок** - корректная обработка ошибок загрузки

### API компонента

#### Атрибуты
```html
<!-- Базовое использование -->
<icon-loader url="https://example.com"></icon-loader>

<!-- С указанием размера -->
<icon-loader url="https://example.com" size="24"></icon-loader>

<!-- С отключенным кэшированием -->
<icon-loader url="https://example.com" no-cache></icon-loader>

<!-- С отключенным Google Favicon Service -->
<icon-loader url="https://example.com" no-google></icon-loader>
```

#### JavaScript API
```javascript
// Получение компонента
const iconLoader = document.querySelector('icon-loader');

// Загрузка иконки для нового URL
iconLoader.loadIcon('https://example.com');

// Очистка кэша
iconLoader.clearCache();

// Получение кэшированной иконки
const cachedIcon = iconLoader.getCachedIcon('https://example.com');
```

### События
```javascript
// Событие успешной загрузки иконки
iconLoader.addEventListener('icon-loaded', (event) => {
    console.log('Icon loaded:', event.detail.url);
});

// Событие ошибки загрузки иконки
iconLoader.addEventListener('icon-error', (event) => {
    console.log('Icon error:', event.detail.url, event.detail.error);
});
```

## Особенности реализации

### Алгоритм загрузки иконок

Компонент использует следующий алгоритм для загрузки иконок:

1. Проверка кэша - если иконка уже загружена, используется кэшированная версия
2. Прямая загрузка favicon - попытка загрузить favicon напрямую с сайта
3. Google Favicon Service - если прямая загрузка не удалась, используется Google Favicon Service
4. Резервная иконка - если все методы не удались, отображается стандартная иконка

```javascript
async loadIcon(url) {
    // Показать индикатор загрузки
    this.showLoader();
    
    // Проверить кэш
    const cachedIcon = this.getCachedIcon(url);
    if (cachedIcon) {
        this.setIcon(cachedIcon);
        this.hideLoader();
        return;
    }
    
    try {
        // Попытка прямой загрузки
        const iconData = await this.fetchFavicon(url);
        this.setIcon(iconData);
        this.cacheIcon(url, iconData);
    } catch (error) {
        try {
            // Попытка через Google Favicon Service
            const googleIconData = await this.fetchGoogleFavicon(url);
            this.setIcon(googleIconData);
            this.cacheIcon(url, googleIconData);
        } catch (googleError) {
            // Использование резервной иконки
            this.loadFallbackIcon();
        }
    } finally {
        this.hideLoader();
    }
}
```

### Кэширование

Компонент реализует простую систему кэширования иконок в памяти:

```javascript
cacheIcon(url, iconData) {
    if (this.hasAttribute('no-cache')) return;
    
    // Извлечение домена из URL
    const domain = new URL(url).hostname;
    
    // Сохранение иконки в кэше
    this.iconCache[domain] = iconData;
}

getCachedIcon(url) {
    if (this.hasAttribute('no-cache')) return null;
    
    // Извлечение домена из URL
    const domain = new URL(url).hostname;
    
    // Получение иконки из кэша
    return this.iconCache[domain] || null;
}

clearCache() {
    this.iconCache = {};
}
```

### Обработка ошибок

Компонент обеспечивает надежную обработку ошибок загрузки иконок:

```javascript
handleError(url, error) {
    // Скрыть индикатор загрузки
    this.hideLoader();
    
    // Показать резервную иконку
    this.showFallbackIcon();
    
    // Отправить событие ошибки
    this.dispatchEvent(new CustomEvent('icon-error', {
        detail: { url, error }
    }));
}
```

## Интеграция в PAGE X

### Использование в Tabs Container

Компонент Icon Loader интегрирован в компонент Tabs Container для отображения иконок вкладок:

```javascript
// В tabs-container.js
renderTab(tab) {
    const tabElement = document.createElement('div');
    tabElement.className = 'tab';
    tabElement.dataset.id = tab.id;
    
    // Создание и настройка Icon Loader
    const iconLoader = document.createElement('icon-loader');
    iconLoader.setAttribute('url', tab.url);
    iconLoader.setAttribute('size', '16');
    
    // Создание заголовка вкладки
    const tabTitle = document.createElement('span');
    tabTitle.className = 'tab-title';
    tabTitle.textContent = tab.title;
    
    // Добавление элементов в вкладку
    tabElement.appendChild(iconLoader);
    tabElement.appendChild(tabTitle);
    
    return tabElement;
}
```

### Конфигурация

```javascript
// В userconfig.js
iconLoader: {
    enabled: true,           // Включить/выключить
    cacheEnabled: true,      // Включить/выключить кэширование
    useGoogleService: true,  // Использовать Google Favicon Service
    defaultSize: 16,         // Размер иконок по умолчанию
    cacheTTL: 86400000      // Время жизни кэша (24 часа)
}
```

## Тестирование

### Тестовая страница

```html
<!-- test-icon-loader.html -->
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тест Icon Loader</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #282828;
            color: #ebdbb2;
        }
        
        .test-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .test-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            border: 1px solid #504945;
            border-radius: 4px;
        }
        
        .test-url {
            flex-grow: 1;
        }
        
        .test-button {
            background-color: #504945;
            color: #ebdbb2;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .test-button:hover {
            background-color: #665c54;
        }
        
        .test-input {
            background-color: #3c3836;
            color: #ebdbb2;
            border: 1px solid #504945;
            padding: 5px 10px;
            border-radius: 4px;
            width: 100%;
        }
    </style>
</head>
<body>
    <h1>Тест Icon Loader</h1>
    
    <div class="test-container">
        <div class="test-item">
            <icon-loader url="https://google.com" size="24"></icon-loader>
            <div class="test-url">https://google.com</div>
            <button class="test-button" onclick="reloadIcon(this)">Reload</button>
        </div>
        
        <div class="test-item">
            <icon-loader url="https://github.com" size="24"></icon-loader>
            <div class="test-url">https://github.com</div>
            <button class="test-button" onclick="reloadIcon(this)">Reload</button>
        </div>
        
        <div class="test-item">
            <icon-loader url="https://example.com" size="24"></icon-loader>
            <div class="test-url">https://example.com</div>
            <button class="test-button" onclick="reloadIcon(this)">Reload</button>
        </div>
        
        <div class="test-item">
            <icon-loader url="https://nonexistent-site-12345.com" size="24"></icon-loader>
            <div class="test-url">https://nonexistent-site-12345.com</div>
            <button class="test-button" onclick="reloadIcon(this)">Reload</button>
        </div>
        
        <div class="test-item">
            <input type="text" class="test-input" placeholder="Enter URL...">
            <icon-loader size="24"></icon-loader>
            <button class="test-button" onclick="loadCustomIcon(this)">Load</button>
        </div>
    </div>
    
    <div style="margin-top: 20px;">
        <button class="test-button" onclick="clearCache()">Clear Cache</button>
    </div>
    
    <!-- Components -->
    <script src="src/components/icon-loader.js"></script>
    
    <!-- Test Scripts -->
    <script>
        function reloadIcon(button) {
            const item = button.parentElement;
            const iconLoader = item.querySelector('icon-loader');
            const url = item.querySelector('.test-url').textContent;
            
            iconLoader.loadIcon(url);
        }
        
        function loadCustomIcon(button) {
            const item = button.parentElement;
            const iconLoader = item.querySelector('icon-loader');
            const input = item.querySelector('.test-input');
            const url = input.value;
            
            if (url) {
                iconLoader.loadIcon(url);
            }
        }
        
        function clearCache() {
            const iconLoaders = document.querySelectorAll('icon-loader');
            iconLoaders.forEach(loader => loader.clearCache());
            alert('Cache cleared!');
        }
    </script>
</body>
</html>
```

## Совместимость

### Браузеры
- ✅ Chrome 60+
- ✅ Firefox 55+
- ✅ Safari 10.1+
- ✅ Edge 79+

### Ограничения
- ⚠️ CORS - некоторые сайты могут блокировать прямую загрузку favicon
- ⚠️ Mixed Content - проблемы при загрузке HTTP-ресурсов на HTTPS-страницах
- ⚠️ Сетевые ограничения - зависимость от доступности внешних ресурсов

## Рекомендации по улучшению

### Технические улучшения
1. **Локальное хранилище** - использование localStorage для долгосрочного кэширования
2. **Предзагрузка** - предварительная загрузка часто используемых иконок
3. **Оптимизация запросов** - использование batch-запросов для загрузки нескольких иконок
4. **Поддержка SVG** - улучшенная поддержка SVG-иконок
5. **Сжатие** - оптимизация размера иконок

### Функциональные улучшения
1. **Настраиваемые резервные иконки** - возможность указать пользовательскую резервную иконку
2. **Дополнительные источники** - поддержка других сервисов иконок
3. **Автоматическое обновление** - периодическое обновление кэшированных иконок
4. **Приоритизация** - загрузка иконок в порядке приоритета
5. **Отложенная загрузка** - загрузка иконок только при видимости элемента

## Заключение

Компонент Icon Loader представляет собой эффективное решение для автоматической загрузки и отображения иконок сайтов в проекте PAGE X. Компонент обеспечивает надежную загрузку иконок из различных источников, реализует кэширование для повышения производительности и предоставляет гибкий API для интеграции в другие компоненты.

Использование Web Components и Shadow DOM обеспечивает инкапсуляцию стилей и функциональности, что делает компонент независимым и переиспользуемым. Компонент также обеспечивает хорошую обработку ошибок и предоставляет резервные варианты для случаев, когда загрузка иконок не удается.

Дальнейшее развитие компонента может включать улучшение системы кэширования, поддержку дополнительных источников иконок и оптимизацию производительности.